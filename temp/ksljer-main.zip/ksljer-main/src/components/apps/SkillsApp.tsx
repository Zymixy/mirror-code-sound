export function SkillsApp() {
  return (
    <div className="flex items-center justify-center h-full min-h-[200px]">
      <p className="text-lg text-muted-foreground text-center">
        No skills because I have no brain
      </p>
    </div>
  );
}
