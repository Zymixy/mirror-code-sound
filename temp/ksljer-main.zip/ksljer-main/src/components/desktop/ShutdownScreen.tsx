export function ShutdownScreen() {
  return (
    <div className="fixed inset-0 bg-black z-[9999]" />
  );
}
